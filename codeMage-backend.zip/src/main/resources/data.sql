-- Géneros
INSERT INTO genre (id, name) VALUES (1, 'Acción');
INSERT INTO genre (id, name) VALUES (2, 'Drama');
INSERT INTO genre (id, name) VALUES (3, 'Comedia');
INSERT INTO genre (id, name) VALUES (4, 'Terror');
INSERT INTO genre (id, name) VALUES (5, 'Ciencia Ficción');

-- Películas
INSERT INTO movie (id, title, year, director, genre_id) VALUES (1, 'Mad Max: Fury Road', 2015, 'George Miller', 1);
INSERT INTO movie (id, title, year, director, genre_id) VALUES (2, 'John Wick', 2014, 'Chad Stahelski', 1);
INSERT INTO movie (id, title, year, director, genre_id) VALUES (3, 'The Shawshank Redemption', 1994, 'Frank Darabont', 2);
INSERT INTO movie (id, title, year, director, genre_id) VALUES (4, 'Forrest Gump', 1994, 'Robert Zemeckis', 2);
INSERT INTO movie (id, title, year, director, genre_id) VALUES (5, 'The Grand Budapest Hotel', 2014, 'Wes Anderson', 3);
INSERT INTO movie (id, title, year, director, genre_id) VALUES (6, 'The Shining', 1980, 'Stanley Kubrick', 4);
INSERT INTO movie (id, title, year, director, genre_id) VALUES (7, 'Interstellar', 2014, 'Christopher Nolan', 5);
INSERT INTO movie (id, title, year, director, genre_id) VALUES (8, 'Blade Runner 2049', 2017, 'Denis Villeneuve', 5);
