package com.codemage.dto;

import jakarta.validation.constraints.*;

public class MovieRequestDTO {

    @NotBlank(message = "El título no puede estar vacío")
    private String title;

    @NotNull(message = "El año no puede ser nulo")
    @Min(value = 1888, message = "El año debe ser mayor a 1888")
    @Max(value = 2100, message = "El año no puede ser mayor a 2100")
    private Integer year;

    @NotBlank(message = "El director no puede estar vacío")
    private String director;

    @NotNull(message = "El género es obligatorio")
    private Long genreId;

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public Long getGenreId() { return genreId; }
    public void setGenreId(Long genreId) { this.genreId = genreId; }
}
