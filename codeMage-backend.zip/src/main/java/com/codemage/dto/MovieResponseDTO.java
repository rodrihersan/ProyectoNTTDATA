package com.codemage.dto;

public class MovieResponseDTO {

    private Long id;
    private String title;
    private Integer year;
    private String director;
    private Long genreId;
    private String genreName;

    public MovieResponseDTO() {}

    public MovieResponseDTO(Long id, String title, Integer year,
                            String director, Long genreId, String genreName) {
        this.id = id;
        this.title = title;
        this.year = year;
        this.director = director;
        this.genreId = genreId;
        this.genreName = genreName;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public Long getGenreId() { return genreId; }
    public void setGenreId(Long genreId) { this.genreId = genreId; }

    public String getGenreName() { return genreName; }
    public void setGenreName(String genreName) { this.genreName = genreName; }
}
