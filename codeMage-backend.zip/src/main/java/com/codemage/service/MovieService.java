package com.codemage.service;

import com.codemage.dto.MovieRequestDTO;
import com.codemage.dto.MovieResponseDTO;
import com.codemage.model.Genre;
import com.codemage.model.Movie;
import com.codemage.repository.MovieRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MovieService {

    private final MovieRepository movieRepository;
    private final GenreService genreService;

    public MovieService(MovieRepository movieRepository, GenreService genreService) {
        this.movieRepository = movieRepository;
        this.genreService = genreService;
    }

    public List<MovieResponseDTO> findAll() {
        return movieRepository.findAll()
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public MovieResponseDTO findById(Long id) {
        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Película no encontrada con id: " + id));
        return toResponseDTO(movie);
    }

    public List<MovieResponseDTO> findByGenreId(Long genreId) {
        genreService.findById(genreId);
        return movieRepository.findByGenreId(genreId)
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public List<MovieResponseDTO> findByTitle(String title) {
        return movieRepository.findByTitleContainingIgnoreCase(title)
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public MovieResponseDTO create(MovieRequestDTO dto) {
        Genre genre = genreService.findById(dto.getGenreId());
        Movie movie = new Movie(dto.getTitle(), dto.getYear(), dto.getDirector(), genre);
        return toResponseDTO(movieRepository.save(movie));
    }

    public MovieResponseDTO update(Long id, MovieRequestDTO dto) {
        Movie existing = movieRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Película no encontrada con id: " + id));

        Genre genre = genreService.findById(dto.getGenreId());
        existing.setTitle(dto.getTitle());
        existing.setYear(dto.getYear());
        existing.setDirector(dto.getDirector());
        existing.setGenre(genre);

        return toResponseDTO(movieRepository.save(existing));
    }

    public void delete(Long id) {
        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Película no encontrada con id: " + id));
        movieRepository.delete(movie);
    }

    private MovieResponseDTO toResponseDTO(Movie movie) {
        return new MovieResponseDTO(
                movie.getId(),
                movie.getTitle(),
                movie.getYear(),
                movie.getDirector(),
                movie.getGenre().getId(),
                movie.getGenre().getName()
        );
    }
}
