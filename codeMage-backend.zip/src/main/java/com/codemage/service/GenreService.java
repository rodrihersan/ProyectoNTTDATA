package com.codemage.service;

import com.codemage.model.Genre;
import com.codemage.repository.GenreRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenreService {

    private final GenreRepository genreRepository;

    public GenreService(GenreRepository genreRepository) {
        this.genreRepository = genreRepository;
    }

    public List<Genre> findAll() {
        return genreRepository.findAll();
    }

    public Genre findById(Long id) {
        return genreRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Género no encontrado con id: " + id));
    }

    public Genre create(Genre genre) {
        if (genreRepository.existsByNameIgnoreCase(genre.getName())) {
            throw new RuntimeException("Ya existe un género con el nombre: " + genre.getName());
        }
        return genreRepository.save(genre);
    }

    public Genre update(Long id, Genre genreData) {
        Genre existing = findById(id);

        genreRepository.findByNameIgnoreCase(genreData.getName())
                .filter(g -> !g.getId().equals(id))
                .ifPresent(g -> { throw new RuntimeException("Ya existe un género con ese nombre"); });

        existing.setName(genreData.getName());
        return genreRepository.save(existing);
    }

    public void delete(Long id) {
        Genre genre = findById(id);
        if (!genre.getMovies().isEmpty()) {
            throw new RuntimeException("No se puede eliminar un género que tiene películas asociadas");
        }
        genreRepository.delete(genre);
    }
}
